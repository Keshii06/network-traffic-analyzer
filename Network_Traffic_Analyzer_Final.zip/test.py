print("🎉 Testing Python...")
import scapy.all
import matplotlib.pyplot
import pandas
import numpy
print("✅ All libraries working!")
print("Ready for cn mini project!")      
